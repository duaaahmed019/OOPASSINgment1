import java.util.ArrayList;
import java.util.List;

// Enumeration for product types
enum ProductType {
    BREAD, CAKE, PASTRY
}

// Product class to represent bakery items
class Product {
    String name;
    double price;
    ProductType type;

    public Product(String name, double price, ProductType type) {
        this.name = name;
        this.price = price;
        this.type = type;
    }
}

// Bakery class to manage products
class Bakery {
    List<Product> products = new ArrayList<>();

    public void addProduct(String name, double price, ProductType type) {
        products.add(new Product(name, price, type));
    }

    public void listProducts() {
        System.out.println("Available Bakery Products:");
        for (Product product : products) {
            System.out.println(product.name + " - $" + product.price + " (" + product.type + ")");
        }
    }
}

public class SimpleBakerySystem {
    public static void main(String[] args) {
        Bakery bakery = new Bakery();

        bakery.addProduct("Baguette", 3.50, ProductType.BREAD);
        bakery.addProduct("Chocolate Cake", 12.99, ProductType.CAKE);
        bakery.addProduct("Croissant", 2.25, ProductType.PASTRY);

        bakery.listProducts();
    }
}


